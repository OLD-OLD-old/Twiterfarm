# 🐦 Twitter Farm - Automação Multi-Contas

Sistema completo 100% GRATUITO para automação no Twitter.

## 🎯 Funcionalidades

- **Contas POSTADORAS:** Postam + comentam link Telegram
- **Contas ENGAJADORAS:** RT + Like + Save automaticamente
- **100% FREE:** Usa Twitter API gratuita (R$ 0/mês)
- **Humanizado:** Delays, variação, comportamento natural

## 🚀 Instalação Rápida

```bash
# 1. Instalar dependências
pip install -r requirements.txt

# 2. Configurar
cp .env.example .env
# Edite: config/contas_twitter.json

# 3. Executar
python app/twitter_bot.py
```

## 📖 Documentação

- [GUIA_TWITTER_FARM.md](GUIA_TWITTER_FARM.md) - Instalação completa
- [ESTRATEGIA_FREE.md](ESTRATEGIA_FREE.md) - Como usar gratuitamente

## 💰 Custo: R$ 0,00/mês

Com 5 postadoras + 20 engajadoras:
- 125 posts/dia
- 1.500 engajamentos/dia  
- **Custo: ZERO!**

**Boa automação! 🚀**
